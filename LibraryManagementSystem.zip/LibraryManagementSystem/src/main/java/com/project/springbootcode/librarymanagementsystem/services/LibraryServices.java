package com.project.springbootcode.librarymanagementsystem.services;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.springbootcode.librarymanagementsystem.model.Book;
import com.project.springbootcode.librarymanagementsystem.repository.BookRepository;

@Service
public class LibraryServices implements ILibraryService {

	@Autowired
	private BookRepository bookRepository;
	
	@Override
	public Integer saveBookInfo(Book book) {
		book = bookRepository.save(book);
		return book.getBookId();
	}

	@Override
	public Book updateBookInfo(Book book) {
		book = bookRepository.save(book);
		return book;
	}

	@Override
	public List<Book> getAllBookInfo() {
		return bookRepository.findAll();
	}

	@Override
	public Book getBookInfoById(Integer bookId) {
		Optional<Book> optionalBook =  bookRepository.findById(bookId);
		if(optionalBook.isPresent()) {
			return optionalBook.get();
		}
		return null;
	}

	@Override
	public void deleteBookById(Integer bookId) {
		bookRepository.deleteById(bookId);
	}

}
