package com.project.springbootcode.librarymanagementsystem.services;

import java.util.List;

import com.project.springbootcode.librarymanagementsystem.model.Book;


public interface ILibraryService {

	Integer saveBookInfo(Book book);
	Book updateBookInfo(Book book);
	List<Book> getAllBookInfo();
	Book getBookInfoById(Integer bookId);
	void deleteBookById(Integer bookId);
	
}
