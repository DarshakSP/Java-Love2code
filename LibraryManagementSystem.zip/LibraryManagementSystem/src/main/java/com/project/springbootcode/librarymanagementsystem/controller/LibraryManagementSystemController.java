package com.project.springbootcode.librarymanagementsystem.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.project.springbootcode.librarymanagementsystem.model.Book;
import com.project.springbootcode.librarymanagementsystem.services.ILibraryService;

@RestController
@RequestMapping("/lms")
public class LibraryManagementSystemController {

	@Value("${author.name}")
	public String authorName;
	
	@Autowired
	private ILibraryService	libraryService;
	
	@GetMapping("/welcome")
	public String welcomePage(){
		return "<h1>Welcome "+ authorName +"</h1> <br>"+"<h1> Connection done </h1>";
	}
	
	@PostMapping("/save")
	public String saveBookInfo(@RequestBody Book book){
		Integer bookId = libraryService.saveBookInfo(book);
		return "Book info is added for ID : " + bookId;
	}
	
	@PutMapping("/update")
	public String updateBookInfo(@RequestBody Book book){
		Integer bookId = libraryService.saveBookInfo(book);
		return "Book info is updated for ID : "+bookId;
		
	}
	
	@GetMapping("/getAllBooks")
	public List<Book> getAllBookInfo() {
		return libraryService.getAllBookInfo();
		
	}
	
	@RequestMapping("/getBooksById/{id}")
	public Book getBookInfoById(@PathVariable Integer id){
		return libraryService.getBookInfoById(id);
	}
	
	@DeleteMapping("/deleteBookById/{id}")
	public String deleteBookInfoById(@PathVariable Integer id){
		libraryService.deleteBookById(id);
		return "Book info is deleted for ID : "+ id;
	}
	
}
